#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

# Load the dataset
df = pd.read_csv("heart_disease_health_indicators_BRFSS2015.csv")

# Check for and drop missing values
if df.isnull().sum().sum() == 0:
    print("No missing values found.")
else:
    print("Missing values detected. Dropping rows with missing values...")
    df.dropna(inplace=True)
    print("Missing values removed.")

# Simplify 'Diabetes' column (convert all non-zero values to 1)
df['Diabetes'] = df['Diabetes'].apply(lambda x: 1 if x != 0 else 0)

# Convert ordinal fields to integer
ordinal_columns = ['Age', 'Education', 'Income', 'GenHlth']
df[ordinal_columns] = df[ordinal_columns].astype(int)

# Validate binary columns
binary_columns = [
    'HighBP', 'HighChol', 'CholCheck', 'Smoker', 'Stroke', 'Diabetes',
    'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump',
    'AnyHealthcare', 'NoDocbcCost', 'DiffWalk', 'Sex'
]
for col in binary_columns:
    assert set(df[col].unique()).issubset({0, 1}), f"{col} contains unexpected values!"

# Check class imbalance in the target
target_counts = df['HeartDiseaseorAttack'].value_counts()
print("\nClass Distribution (Target):")
print(target_counts)
sns.countplot(x='HeartDiseaseorAttack', data=df)
plt.title('Target Class Distribution')
plt.xlabel('Heart Disease or Attack (0 = No, 1 = Yes)')
plt.ylabel('Count')
plt.tight_layout()
plt.show()

# Detect potential outliers in BMI and health days
df = df[df['BMI'] <= 60]
outliers_bmi = df[df['BMI'] > 60]
print(f"\nBMI Outliers (BMI > 60): {len(outliers_bmi)} rows")

# Normalize continuous variables
scaler = MinMaxScaler()
df[['BMI', 'MentHlth', 'PhysHlth']] = scaler.fit_transform(df[['BMI', 'MentHlth', 'PhysHlth']])
print("Scaled continuous variables (BMI, MentHlth, PhysHlth)")

# Export cleaned dataset
df.to_csv("heart_2015_scaled_cleaned.csv", index=False)
print("\nCleaned dataset saved as 'heart_2015_scaled_cleaned.csv'.")


# In[ ]:




