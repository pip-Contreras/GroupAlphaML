#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# Load the dataset
df = pd.read_csv("heart_2022_with_nans.csv")

# Extract and show missing values
missing = df.isnull().sum()
missing = missing[missing > 0]

# Drop rows with missing values
df.dropna(inplace=True)
print("\nShape after dropping missing values:", df.shape)

# Standardize Yes/No values to 1/0
yes_no_columns = [
    'PhysicalActivities', 'HadHeartAttack', 'HadAngina', 'HadStroke', 'HadAsthma',
    'HadSkinCancer', 'HadCOPD', 'HadDepressiveDisorder', 'HadKidneyDisease',
    'HadArthritis', 'HadDiabetes', 'DeafOrHardOfHearing', 'BlindOrVisionDifficulty',
    'DifficultyConcentrating', 'DifficultyWalking', 'DifficultyDressingBathing',
    'DifficultyErrands', 'AlcoholDrinkers', 'HIVTesting', 'FluVaxLast12',
    'PneumoVaxEver', 'HighRiskLastYear', 'CovidPos'
]
for col in yes_no_columns:
    df[col] = df[col].map(lambda x: 1 if x == "Yes" else 0)

# Drop irrelevant columns
df.drop(columns=["State"], inplace=True)

# Label encode remaining categorical columns
label_columns = [
    'Sex', 'GeneralHealth', 'LastCheckupTime', 'SmokerStatus',
    'ECigaretteUsage', 'ChestScan', 'RaceEthnicityCategory', 'AgeCategory',
    'TetanusLast10Tdap'
]
label_encoder = LabelEncoder()
for col in label_columns:
    df[col] = label_encoder.fit_transform(df[col])

# Define and isolate the target variable
target_column = 'HadHeartAttack'
X = df.drop(columns=[target_column])  # Features
y = df[target_column]                 # Target

# Plot countplot for target variable
target_counts = df['HadHeartAttack'].value_counts()
print("\nClass Distribution (Target):")
print(target_counts)
sns.countplot(x=target_column, data=df)
plt.title("Count of Heart Attack Cases")
plt.xlabel("Had Heart Attack (0 = No, 1 = Yes)")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

# Save cleaned dataset
df.to_csv("heart_2022_scaled_cleaned.csv", index=False)
print("\nCleaned dataset saved as 'heart_2022_scaled_cleaned.csv'.")


# In[ ]:




