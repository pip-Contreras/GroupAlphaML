README - Dataset Cleaning

The project involved two heart disease-related datasets: one from the 2015 BRFSS survey and another from 2022, both of which required thorough data cleaning to prepare them for analysis and modeling.

For the BRFSS 2015 dataset, the cleaning process began by verifying that the dataset contained no missing values. The Diabetes column, which originally had multiple categories, was simplified into a binary format indicating the presence or absence of any form of diabetes. Several categorical features with binary outcomes (such as Smoker, HighBP, Stroke) were validated to ensure they contained only 0 or 1. Ordinal columns like Age, Education, Income, and GenHlth were converted from float to integer types for clarity and consistency. The age column in the dataset ranges from values of 1-13, representing an increase of 5 years starting at 18 years of age. A correlation heatmap was generated to identify feature relationships, and a countplot of the target variable (HeartDiseaseorAttack) was used to assess class imbalance. Finally, the cleaned dataset was exported as heart_2015_scaled_cleaned.csv.

For the 2015 Dataset:
Value	Age Range
1	18–24 years
2	25–29 years
3	30–34 years
4	35–39 years
5	40–44 years
6	45–49 years
7	50–54 years
8	55–59 years
9	60–64 years
10	65–69 years
11	70–74 years
12	75–79 years
13	80 years or older  
*Does not need to be included, just to show one of the more confusing variables and how it is listed.

The 2022 dataset required more extensive cleaning due to a high volume of missing values. First, all rows with any missing values were dropped, reducing the dataset significantly in size. A set of 23 categorical columns with "Yes"/"No" responses were standardized to binary values (1 for "Yes", 0 for "No"). The State column was removed as it was not relevant to predictive modeling. Additional categorical variables (such as Sex, GeneralHealth, RaceEthnicityCategory, etc.) were label encoded to convert textual categories into numeric values. The target variable for modeling, HadHeartAttack, was defined and isolated from the feature set. As with the 2015 dataset, a countplot was created to visualize class distribution, and a correlation heatmap was used to evaluate feature relationships. The cleaned dataset was saved as heart_2022_scaled_cleaned.csv.